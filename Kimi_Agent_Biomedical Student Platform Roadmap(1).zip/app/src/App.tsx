import { useEffect, useRef, useLayoutEffect } from 'react';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { 
  Microscope, 
  FlaskConical, 
  Users, 
  UserCircle, 
  BookOpen, 
  GraduationCap,
  Instagram,
  Twitter,
  Linkedin,
  Play,
  ArrowRight,
  Mail,
  MapPin,
  Phone
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

// Navigation items
const navItems = [
  { icon: GraduationCap, label: 'Courses' },
  { icon: FlaskConical, label: 'Labs' },
  { icon: Users, label: 'Community' },
  { icon: UserCircle, label: 'Mentorship' },
  { icon: BookOpen, label: 'Research' },
];

// Section component props
interface SectionProps {
  children: React.ReactNode;
  className?: string;
  zIndex: number;
}

const PinnedSection = ({ children, className = '', zIndex }: SectionProps) => (
  <section 
    className={`section-pinned flex items-center justify-center ${className}`}
    style={{ zIndex }}
  >
    {children}
  </section>
);

function App() {
  const mainRef = useRef<HTMLDivElement>(null);
  const heroHeadlineRef = useRef<HTMLDivElement>(null);
  const heroSubRef = useRef<HTMLDivElement>(null);
  const heroCTARef = useRef<HTMLDivElement>(null);
  const heroCollageRef = useRef<HTMLDivElement>(null);
  const navRef = useRef<HTMLDivElement>(null);

  // Load animation (auto-play on mount)
  useEffect(() => {
    const ctx = gsap.context(() => {
      const tl = gsap.timeline({ defaults: { ease: 'power3.out' } });

      // Nav fade in
      tl.fromTo(navRef.current, 
        { opacity: 0 }, 
        { opacity: 1, duration: 0.4 },
        0
      );

      // Headline words stagger
      if (heroHeadlineRef.current) {
        const words = heroHeadlineRef.current.querySelectorAll('.headline-word');
        tl.fromTo(words,
          { y: 40, opacity: 0 },
          { y: 0, opacity: 1, duration: 0.7, stagger: 0.05 },
          0.2
        );
      }

      // Subheadline + CTA
      tl.fromTo([heroSubRef.current, heroCTARef.current],
        { y: 24, opacity: 0 },
        { y: 0, opacity: 1, duration: 0.6, stagger: 0.1 },
        0.6
      );

      // Collage tiles stagger
      if (heroCollageRef.current) {
        const tiles = heroCollageRef.current.querySelectorAll('.collage-tile');
        tl.fromTo(tiles,
          { x: '12vw', scale: 0.92, opacity: 0 },
          { x: 0, scale: 1, opacity: 1, duration: 0.7, stagger: 0.08 },
          0.3
        );
      }
    });

    return () => ctx.revert();
  }, []);

  // Scroll-driven animations
  useLayoutEffect(() => {
    const ctx = gsap.context(() => {
      const pinnedSections = gsap.utils.toArray<HTMLElement>('.section-pinned');
      
      // Hero exit animation
      const heroSection = pinnedSections[0];
      if (heroSection) {
        ScrollTrigger.create({
          trigger: heroSection,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onUpdate: (self) => {
            const progress = self.progress;
            
            // Exit phase (70% - 100%)
            if (progress > 0.7) {
              const exitProgress = (progress - 0.7) / 0.3;
              
              if (heroHeadlineRef.current) {
                gsap.set(heroHeadlineRef.current, {
                  x: -28 * exitProgress + 'vw',
                  opacity: progress > 0.95 ? 0 : 1 - exitProgress * 0.75
                });
              }
              
              if (heroCollageRef.current) {
                gsap.set(heroCollageRef.current, {
                  x: 18 * exitProgress + 'vw',
                  scale: 1 - 0.04 * exitProgress,
                  opacity: progress > 0.95 ? 0 : 1 - exitProgress * 0.7
                });
              }
              
              if (heroCTARef.current) {
                gsap.set(heroCTARef.current, {
                  y: -10 * exitProgress + 'vh',
                  opacity: 1 - exitProgress
                });
              }
            }
          },
          onLeaveBack: () => {
            // Reset to visible when scrolling back to top
            if (heroHeadlineRef.current) {
              gsap.set(heroHeadlineRef.current, { x: 0, opacity: 1 });
            }
            if (heroCollageRef.current) {
              gsap.set(heroCollageRef.current, { x: 0, scale: 1, opacity: 1 });
            }
            if (heroCTARef.current) {
              gsap.set(heroCTARef.current, { y: 0, opacity: 1 });
            }
          }
        });
      }

      // Sections 2-8 animations
      for (let i = 1; i < pinnedSections.length; i++) {
        const section = pinnedSections[i];
        const isLeftDominant = i % 2 === 1; // Sections 2, 4, 6, 8 have left dominant
        
        const mediaTile = section.querySelector('.media-dominant');
        const textBlock = section.querySelector('.text-block');
        const accentTile = section.querySelector('.accent-tile');
        const divider = section.querySelector('.divider-line');
        const headline = section.querySelector('.headline-animate');

        ScrollTrigger.create({
          trigger: section,
          start: 'top top',
          end: '+=130%',
          pin: true,
          scrub: 0.6,
          onUpdate: (self) => {
            const progress = self.progress;
            
            // ENTRANCE (0% - 30%)
            if (progress <= 0.3) {
              const entranceProgress = progress / 0.3;
              
              if (mediaTile) {
                const startX = isLeftDominant ? -60 : 60;
                gsap.set(mediaTile, {
                  x: startX * (1 - entranceProgress) + 'vw',
                  opacity: entranceProgress
                });
              }
              
              if (textBlock) {
                const startX = isLeftDominant ? 40 : -40;
                gsap.set(textBlock, {
                  x: startX * (1 - entranceProgress) + 'vw',
                  opacity: entranceProgress
                });
              }
              
              if (accentTile) {
                const startY = i <= 4 ? -30 : 30;
                gsap.set(accentTile, {
                  y: startY * (1 - entranceProgress) + 'vh',
                  scale: 0.9 + 0.1 * entranceProgress,
                  opacity: entranceProgress
                });
              }
              
              if (divider) {
                gsap.set(divider, {
                  scaleY: entranceProgress
                });
              }
              
              if (headline) {
                const startX = i === 7 ? -40 : (isLeftDominant ? -40 : 40);
                gsap.set(headline, {
                  x: startX * (1 - entranceProgress) + 'vw',
                  opacity: entranceProgress
                });
              }
            }
            // SETTLE (30% - 70%)
            else if (progress <= 0.7) {
              if (mediaTile) gsap.set(mediaTile, { x: 0, opacity: 1 });
              if (textBlock) gsap.set(textBlock, { x: 0, opacity: 1 });
              if (accentTile) gsap.set(accentTile, { y: 0, scale: 1, opacity: 1 });
              if (divider) gsap.set(divider, { scaleY: 1 });
              if (headline) gsap.set(headline, { x: 0, opacity: 1 });
            }
            // EXIT (70% - 100%)
            else {
              const exitProgress = (progress - 0.7) / 0.3;
              
              if (mediaTile) {
                const endX = isLeftDominant ? -18 : 18;
                gsap.set(mediaTile, {
                  x: endX * exitProgress + 'vw',
                  opacity: progress > 0.95 ? 0 : 1 - exitProgress * 0.75
                });
              }
              
              if (textBlock) {
                const endX = isLeftDominant ? 12 : -12;
                gsap.set(textBlock, {
                  x: endX * exitProgress + 'vw',
                  opacity: progress > 0.95 ? 0 : 1 - exitProgress * 0.75
                });
              }
              
              if (accentTile) {
                const endY = i <= 4 ? -12 : 12;
                gsap.set(accentTile, {
                  y: endY * exitProgress + 'vh',
                  opacity: 1 - exitProgress
                });
              }
              
              if (divider) {
                gsap.set(divider, {
                  scaleY: 1 - exitProgress
                });
              }
              
              if (headline) {
                if (i === 7) {
                  gsap.set(headline, {
                    y: -10 * exitProgress + 'vh',
                    opacity: progress > 0.95 ? 0 : 1 - exitProgress * 0.75
                  });
                }
              }
            }
          }
        });
      }

      // Global snap for pinned sections
      const allTriggers = ScrollTrigger.getAll().filter(st => st.vars.pin);
      const maxScroll = ScrollTrigger.maxScroll(window);
      
      if (maxScroll && allTriggers.length > 0) {
        const pinnedRanges = allTriggers.map(st => ({
          start: st.start / maxScroll,
          end: (st.end ?? st.start) / maxScroll,
          center: (st.start + ((st.end ?? st.start) - st.start) * 0.5) / maxScroll,
        }));

        ScrollTrigger.create({
          snap: {
            snapTo: (value: number) => {
              const inPinned = pinnedRanges.some(r => value >= r.start - 0.02 && value <= r.end + 0.02);
              if (!inPinned) return value;
              
              const target = pinnedRanges.reduce((closest, r) =>
                Math.abs(r.center - value) < Math.abs(closest - value) ? r.center : closest,
                pinnedRanges[0]?.center ?? 0
              );
              return target;
            },
            duration: { min: 0.15, max: 0.35 },
            delay: 0,
            ease: 'power2.out'
          }
        });
      }
    }, mainRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={mainRef} className="relative">
      {/* Grain overlay */}
      <div className="grain-overlay" />
      
      {/* Vignette */}
      <div className="vignette" />

      {/* Left Navigation Rail */}
      <nav ref={navRef} className="left-rail">
        {/* Logo */}
        <div className="mb-auto">
          <div className="w-10 h-10 rounded-full bg-[#E4A43C] flex items-center justify-center">
            <Microscope className="w-5 h-5 text-[#0B3A4C]" />
          </div>
        </div>

        {/* Nav Items */}
        <div className="flex flex-col gap-4 mb-auto">
          {navItems.map((item, idx) => (
            <button
              key={idx}
              className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center hover:bg-white/20 transition-colors"
              title={item.label}
            >
              <item.icon className="w-4 h-4 text-white/80" />
            </button>
          ))}
        </div>

        {/* Join CTA */}
        <div className="mt-auto flex flex-col items-center gap-4">
          <button className="pill pill-accent text-xs">
            Join
          </button>
          <div className="flex flex-col gap-3">
            <Instagram className="w-4 h-4 text-white/50 hover:text-white/80 cursor-pointer transition-colors" />
            <Twitter className="w-4 h-4 text-white/50 hover:text-white/80 cursor-pointer transition-colors" />
            <Linkedin className="w-4 h-4 text-white/50 hover:text-white/80 cursor-pointer transition-colors" />
          </div>
        </div>
      </nav>

      {/* Section 1: Hero */}
      <PinnedSection zIndex={10}>
        <div className="absolute inset-0 bg-[#0B3A4C]" />
        
        {/* Main content area (offset for rail) */}
        <div className="relative w-full h-full pl-[88px]">
          {/* Hero text block */}
          <div 
            ref={heroHeadlineRef}
            className="absolute left-[10vw] top-[18vh] w-[36vw]"
          >
            <h1 className="headline text-[clamp(44px,5vw,78px)] text-[#F7F8F7]">
              <span className="headline-word block">Learn</span>
              <span className="headline-word block">Biomedicine</span>
              <span className="headline-word block">Sharpen Skills</span>
            </h1>
          </div>

          {/* Subheadline */}
          <div 
            ref={heroSubRef}
            className="absolute left-[10vw] top-[56vh] w-[30vw]"
          >
            <p className="body-text text-[clamp(14px,1.2vw,18px)]">
              A modern learning platform for biomedical students—courses, quizzes, labs, and mentorship in one place.
            </p>
          </div>

          {/* CTA Row */}
          <div 
            ref={heroCTARef}
            className="absolute left-[10vw] top-[70vh] flex gap-4"
          >
            <button className="pill pill-accent flex items-center gap-2">
              Explore Courses
              <ArrowRight className="w-4 h-4" />
            </button>
            <button className="pill pill-default">
              Join the Community
            </button>
          </div>

          {/* Media Collage */}
          <div 
            ref={heroCollageRef}
            className="absolute left-[56vw] top-[14vh] w-[38vw] h-[72vh]"
          >
            <div className="grid grid-cols-2 gap-[2.2vw] gap-y-[3vh]">
              {/* Tile 1 - Courses */}
              <div className="collage-tile media-tile w-[17.5vw] h-[33vh] relative">
                <img 
                  src="/images/hero_microscope.jpg" 
                  alt="Courses" 
                  className="w-full h-full object-cover"
                />
                <div className="tile-caption">
                  <span className="label-mono text-[#F7F8F7]/80">Courses</span>
                </div>
              </div>

              {/* Tile 2 - Quizzes */}
              <div className="collage-tile media-tile w-[17.5vw] h-[33vh] relative">
                <img 
                  src="/images/hero_quiz_interface.jpg" 
                  alt="Quizzes" 
                  className="w-full h-full object-cover"
                />
                <div className="play-button">
                  <Play className="w-5 h-5 text-[#0B3A4C] ml-1" fill="#0B3A4C" />
                </div>
                <div className="tile-caption">
                  <span className="label-mono text-[#F7F8F7]/80">Quizzes</span>
                </div>
              </div>

              {/* Tile 3 - Virtual Labs */}
              <div className="collage-tile media-tile w-[17.5vw] h-[33vh] relative">
                <img 
                  src="/images/hero_lab_work.jpg" 
                  alt="Virtual Labs" 
                  className="w-full h-full object-cover"
                />
                <div className="tile-caption">
                  <span className="label-mono text-[#F7F8F7]/80">Virtual Labs</span>
                </div>
              </div>

              {/* Tile 4 - Mentorship */}
              <div className="collage-tile media-tile w-[17.5vw] h-[33vh] relative">
                <img 
                  src="/images/mentorship_meeting.jpg" 
                  alt="Mentorship" 
                  className="w-full h-full object-cover"
                />
                <div className="tile-caption">
                  <span className="label-mono text-[#F7F8F7]/80">Mentorship</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </PinnedSection>

      {/* Section 2: Immersive Learning */}
      <PinnedSection zIndex={20}>
        <div className="absolute inset-0 bg-[#0B3A4C]" />
        <div className="relative w-full h-full pl-[88px]">
          {/* Left dominant media tile */}
          <div className="media-dominant media-tile absolute left-[10vw] top-[16vh] w-[44vw] h-[68vh]">
            <img 
              src="/images/hero_microscope.jpg" 
              alt="Microscopy" 
              className="w-full h-full object-cover"
            />
          </div>

          {/* Divider line */}
          <div 
            className="divider-line divider absolute left-[56vw] top-[18vh] h-[64vh]"
            style={{ transformOrigin: 'top' }}
          />

          {/* Right text block */}
          <div className="text-block absolute left-[60vw] top-[22vh] w-[30vw]">
            <h2 className="headline text-[clamp(34px,3.6vw,56px)] text-[#F7F8F7] mb-6">
              <span className="block">Immersive</span>
              <span className="block">Learning</span>
              <span className="block">Experiences</span>
            </h2>
            <p className="body-text text-[clamp(14px,1.2vw,18px)] mb-8">
              Interactive slides, annotated microscopy, and step-by-step lab walkthroughs that make concepts stick.
            </p>
            <button className="pill pill-accent flex items-center gap-2">
              Try a Virtual Lab
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Accent tile */}
          <div className="accent-tile media-tile absolute left-[74vw] top-[10vh] w-[18vw] h-[22vh] ambient-float">
            <img 
              src="/images/accent_lab.jpg" 
              alt="Lab equipment" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </PinnedSection>

      {/* Section 3: Practical Skills */}
      <PinnedSection zIndex={30}>
        <div className="absolute inset-0 bg-[#0B3A4C]" />
        <div className="relative w-full h-full pl-[88px]">
          {/* Left text block */}
          <div className="text-block absolute left-[10vw] top-[22vh] w-[32vw]">
            <h2 className="headline text-[clamp(34px,3.6vw,56px)] text-[#F7F8F7] mb-6">
              <span className="block">Practical</span>
              <span className="block">Skills</span>
              <span className="block">That Matter</span>
            </h2>
            <p className="body-text text-[clamp(14px,1.2vw,18px)] mb-8">
              From specimen handling to safety protocols—practice real workflows before you step into the lab.
            </p>
            <button className="pill pill-accent flex items-center gap-2">
              Browse Lab Modules
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Divider line */}
          <div 
            className="divider-line divider absolute left-[46vw] top-[18vh] h-[64vh]"
            style={{ transformOrigin: 'top' }}
          />

          {/* Right dominant media tile */}
          <div className="media-dominant media-tile absolute left-[52vw] top-[16vh] w-[44vw] h-[68vh]">
            <img 
              src="/images/hero_lab_work.jpg" 
              alt="Lab training" 
              className="w-full h-full object-cover"
            />
          </div>

          {/* Accent tile */}
          <div className="accent-tile media-tile absolute left-[10vw] top-[68vh] w-[18vw] h-[22vh]">
            <img 
              src="/images/zambia_students.jpg" 
              alt="Students" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </PinnedSection>

      {/* Section 4: Study Together */}
      <PinnedSection zIndex={40}>
        <div className="absolute inset-0 bg-[#0B3A4C]" />
        <div className="relative w-full h-full pl-[88px]">
          {/* Left dominant media tile */}
          <div className="media-dominant media-tile absolute left-[10vw] top-[16vh] w-[44vw] h-[68vh]">
            <img 
              src="/images/hero_study_group.jpg" 
              alt="Study groups" 
              className="w-full h-full object-cover"
            />
          </div>

          {/* Divider line */}
          <div 
            className="divider-line divider absolute left-[56vw] top-[18vh] h-[64vh]"
            style={{ transformOrigin: 'top' }}
          />

          {/* Right text block */}
          <div className="text-block absolute left-[60vw] top-[22vh] w-[30vw]">
            <h2 className="headline text-[clamp(34px,3.6vw,56px)] text-[#F7F8F7] mb-6">
              <span className="block">Study</span>
              <span className="block">Together</span>
              <span className="block">Grow Faster</span>
            </h2>
            <p className="body-text text-[clamp(14px,1.2vw,18px)] mb-8">
              Join topic-based study groups, share notes, and solve problems with peers who get it.
            </p>
            <button className="pill pill-accent flex items-center gap-2">
              Find a Study Group
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Accent tile */}
          <div className="accent-tile media-tile absolute left-[74vw] top-[10vh] w-[18vw] h-[22vh] ambient-float">
            <img 
              src="/images/mosaic_community.jpg" 
              alt="Community" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </PinnedSection>

      {/* Section 5: Quizzes */}
      <PinnedSection zIndex={50}>
        <div className="absolute inset-0 bg-[#0B3A4C]" />
        <div className="relative w-full h-full pl-[88px]">
          {/* Left text block */}
          <div className="text-block absolute left-[10vw] top-[22vh] w-[32vw]">
            <h2 className="headline text-[clamp(34px,3.6vw,56px)] text-[#F7F8F7] mb-6">
              <span className="block">Test</span>
              <span className="block">Your Knowledge</span>
              <span className="block">Track Progress</span>
            </h2>
            <p className="body-text text-[clamp(14px,1.2vw,18px)] mb-8">
              Instant feedback, topic-wise analytics, and personalized recommendations to close gaps.
            </p>
            <button className="pill pill-accent flex items-center gap-2">
              Take a Quiz
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Divider line */}
          <div 
            className="divider-line divider absolute left-[46vw] top-[18vh] h-[64vh]"
            style={{ transformOrigin: 'top' }}
          />

          {/* Right dominant media tile */}
          <div className="media-dominant media-tile absolute left-[52vw] top-[16vh] w-[44vw] h-[68vh]">
            <img 
              src="/images/hero_quiz_interface.jpg" 
              alt="Quiz interface" 
              className="w-full h-full object-cover"
            />
          </div>

          {/* Accent tile */}
          <div className="accent-tile media-tile absolute left-[10vw] top-[68vh] w-[18vw] h-[22vh]">
            <img 
              src="/images/accent_lab.jpg" 
              alt="Lab" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </PinnedSection>

      {/* Section 6: Mentorship */}
      <PinnedSection zIndex={60}>
        <div className="absolute inset-0 bg-[#0B3A4C]" />
        <div className="relative w-full h-full pl-[88px]">
          {/* Left dominant media tile */}
          <div className="media-dominant media-tile absolute left-[10vw] top-[16vh] w-[44vw] h-[68vh]">
            <img 
              src="/images/mentorship_meeting.jpg" 
              alt="Mentorship" 
              className="w-full h-full object-cover"
            />
          </div>

          {/* Divider line */}
          <div 
            className="divider-line divider absolute left-[56vw] top-[18vh] h-[64vh]"
            style={{ transformOrigin: 'top' }}
          />

          {/* Right text block */}
          <div className="text-block absolute left-[60vw] top-[22vh] w-[30vw]">
            <h2 className="headline text-[clamp(34px,3.6vw,56px)] text-[#F7F8F7] mb-6">
              <span className="block">Guidance</span>
              <span className="block">From Those</span>
              <span className="block">Who've Been There</span>
            </h2>
            <p className="body-text text-[clamp(14px,1.2vw,18px)] mb-8">
              Connect with seniors and professionals for advice, CV reviews, and career planning.
            </p>
            <button className="pill pill-accent flex items-center gap-2">
              Meet a Mentor
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Accent tile */}
          <div className="accent-tile media-tile absolute left-[74vw] top-[10vh] w-[18vw] h-[22vh] ambient-float">
            <img 
              src="/images/zambia_students.jpg" 
              alt="Students" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </PinnedSection>

      {/* Section 7: Research */}
      <PinnedSection zIndex={70}>
        <div className="absolute inset-0 bg-[#0B3A4C]" />
        <div className="relative w-full h-full pl-[88px]">
          {/* Left text block */}
          <div className="text-block absolute left-[10vw] top-[22vh] w-[32vw]">
            <h2 className="headline text-[clamp(34px,3.6vw,56px)] text-[#F7F8F7] mb-6">
              <span className="block">Research</span>
              <span className="block">Innovation</span>
              <span className="block">Publish</span>
            </h2>
            <p className="body-text text-[clamp(14px,1.2vw,18px)] mb-8">
              Explore student publications, proposal templates, and journal clubs that turn ideas into impact.
            </p>
            <button className="pill pill-accent flex items-center gap-2">
              Explore Research Hub
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Divider line */}
          <div 
            className="divider-line divider absolute left-[46vw] top-[18vh] h-[64vh]"
            style={{ transformOrigin: 'top' }}
          />

          {/* Right dominant media tile */}
          <div className="media-dominant media-tile absolute left-[52vw] top-[16vh] w-[44vw] h-[68vh]">
            <img 
              src="/images/research_papers.jpg" 
              alt="Research" 
              className="w-full h-full object-cover"
            />
          </div>

          {/* Accent tile */}
          <div className="accent-tile media-tile absolute left-[10vw] top-[68vh] w-[18vw] h-[22vh]">
            <img 
              src="/images/mosaic_innovation.jpg" 
              alt="Innovation" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </PinnedSection>

      {/* Section 8: Full Toolkit (Mosaic) */}
      <PinnedSection zIndex={80}>
        <div className="absolute inset-0 bg-[#0B3A4C]" />
        <div className="relative w-full h-full pl-[88px]">
          {/* Left headline block */}
          <div className="headline-animate absolute left-[10vw] top-[18vh] w-[34vw]">
            <h2 className="headline text-[clamp(34px,3.6vw,56px)] text-[#F7F8F7] mb-6">
              <span className="block">Everything</span>
              <span className="block">You Need</span>
              <span className="block">To Excel</span>
            </h2>
            <p className="body-text text-[clamp(14px,1.2vw,18px)] mb-8">
              Courses • Quizzes • Labs • Groups • Mentorship • Research
            </p>
            <button className="pill pill-accent flex items-center gap-2">
              Get Started
              <ArrowRight className="w-4 h-4" />
            </button>
          </div>

          {/* Right mosaic */}
          <div className="absolute left-[54vw] top-[16vh] w-[40vw] h-[68vh]">
            {/* Top tile */}
            <div className="media-dominant media-tile w-full h-[30vh] mb-[2.4vh]">
              <img 
                src="/images/mosaic_career.jpg" 
                alt="Career" 
                className="w-full h-full object-cover"
              />
            </div>
            
            {/* Bottom row */}
            <div className="flex gap-[2vw]">
              <div className="media-dominant media-tile w-[18.5vw] h-[34vh]">
                <img 
                  src="/images/mosaic_innovation.jpg" 
                  alt="Innovation" 
                  className="w-full h-full object-cover"
                />
              </div>
              <div className="media-dominant media-tile w-[18.5vw] h-[34vh]">
                <img 
                  src="/images/mosaic_community.jpg" 
                  alt="Community" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>

          {/* Micro tile */}
          <div className="accent-tile media-tile absolute left-[10vw] top-[70vh] w-[14vw] h-[18vh]">
            <img 
              src="/images/accent_lab.jpg" 
              alt="Lab" 
              className="w-full h-full object-cover"
            />
          </div>
        </div>
      </PinnedSection>

      {/* Section 9: Contact / CTA (Flowing) */}
      <section className="section-light relative min-h-screen" style={{ zIndex: 90 }}>
        <div className="pl-[88px] py-[10vh]">
          <div className="flex flex-col lg:flex-row gap-12 px-[10vw]">
            {/* Left content */}
            <div className="w-full lg:w-[44vw]">
              <h2 className="headline text-[clamp(34px,3.6vw,56px)] text-[#0B3A4C] mb-6">
                <span className="block">Ready To</span>
                <span className="block">Build Your</span>
                <span className="block">Future?</span>
              </h2>
              
              <p className="text-[#0B3A4C]/70 text-[clamp(14px,1.2vw,18px)] leading-relaxed mb-10">
                Join the Biomedical Student Association of Zambia and get access to courses, labs, mentorship, and a community that supports your growth.
              </p>

              {/* Contact form */}
              <form className="space-y-5">
                <div>
                  <input 
                    type="text" 
                    placeholder="Full Name" 
                    className="form-input"
                  />
                </div>
                <div>
                  <input 
                    type="email" 
                    placeholder="Email Address" 
                    className="form-input"
                  />
                </div>
                <div>
                  <input 
                    type="text" 
                    placeholder="University" 
                    className="form-input"
                  />
                </div>
                <div>
                  <textarea 
                    placeholder="Message" 
                    rows={4}
                    className="form-input resize-none"
                  />
                </div>
                <button 
                  type="submit" 
                  className="w-full py-4 px-6 bg-[#E4A43C] text-[#0B3A4C] rounded-full font-semibold text-sm uppercase tracking-wider hover:bg-[#f0b54a] transition-colors flex items-center justify-center gap-2"
                >
                  Request Access
                  <ArrowRight className="w-4 h-4" />
                </button>
              </form>

              {/* Contact info */}
              <div className="mt-10 space-y-3">
                <div className="flex items-center gap-3 text-[#0B3A4C]/70">
                  <Mail className="w-4 h-4" />
                  <span className="text-sm">hello@bsaz.org</span>
                </div>
                <div className="flex items-center gap-3 text-[#0B3A4C]/70">
                  <MapPin className="w-4 h-4" />
                  <span className="text-sm">Lusaka, Zambia</span>
                </div>
                <div className="flex items-center gap-3 text-[#0B3A4C]/70">
                  <Phone className="w-4 h-4" />
                  <span className="text-sm">+260 XXX XXX XXX</span>
                </div>
              </div>
            </div>

            {/* Right image */}
            <div className="w-full lg:w-[36vw] lg:h-[56vh] mt-8 lg:mt-0">
              <div className="media-tile w-full h-full" style={{ borderColor: 'rgba(11, 58, 76, 0.12)' }}>
                <img 
                  src="/images/zambia_students.jpg" 
                  alt="Zambia biomedical students" 
                  className="w-full h-full object-cover"
                />
              </div>
            </div>
          </div>
        </div>

        {/* Footer */}
        <footer className="bg-[#0B3A4C] text-[#F7F8F7] py-12 px-[10vw] pl-[calc(10vw+88px)]">
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-8">
            <div>
              <div className="flex items-center gap-3 mb-4">
                <div className="w-10 h-10 rounded-full bg-[#E4A43C] flex items-center justify-center">
                  <Microscope className="w-5 h-5 text-[#0B3A4C]" />
                </div>
                <span className="font-display font-bold text-xl">BSAZ</span>
              </div>
              <p className="text-[#F7F8F7]/60 text-sm max-w-sm">
                Building the future of biomedical education in Zambia through community, innovation, and excellence.
              </p>
            </div>
            
            <div className="flex gap-8">
              <div className="flex flex-col gap-2">
                <span className="label-mono text-[#F7F8F7]/40 mb-2">Platform</span>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">Courses</a>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">Virtual Labs</a>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">Quizzes</a>
              </div>
              <div className="flex flex-col gap-2">
                <span className="label-mono text-[#F7F8F7]/40 mb-2">Community</span>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">Study Groups</a>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">Mentorship</a>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">Research Hub</a>
              </div>
              <div className="flex flex-col gap-2">
                <span className="label-mono text-[#F7F8F7]/40 mb-2">Connect</span>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">Instagram</a>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">Twitter</a>
                <a href="#" className="text-sm text-[#F7F8F7]/70 hover:text-[#F7F8F7] transition-colors">LinkedIn</a>
              </div>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t border-[#F7F8F7]/10 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-[#F7F8F7]/40 text-sm">
              © Biomedical Student Association of Zambia. All rights reserved.
            </p>
            <div className="flex gap-6">
              <a href="#" className="text-[#F7F8F7]/40 text-sm hover:text-[#F7F8F7]/70 transition-colors">Privacy Policy</a>
              <a href="#" className="text-[#F7F8F7]/40 text-sm hover:text-[#F7F8F7]/70 transition-colors">Terms of Service</a>
            </div>
          </div>
        </footer>
      </section>
    </div>
  );
}

export default App;
